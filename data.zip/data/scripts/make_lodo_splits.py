# -*- coding: utf-8 -*-
"""make_lodo_splits.py — BIRD leave-one-database-out（11 折）划分。

输入（二选一）:
  1) BIRD dev.json（官方 1,534 题，字段含 db_id）—— 推荐，全量 11 折
  2) 候选池 jsonl（默认 AUC candidates_pool.jsonl，BIRD-300 主池）—— 立即可用

输出: lodo/lodo_splits.json
  {"meta": {...}, "folds": {"<db_id>": {"test_qids": [...]}}}
  每折 = 留出 1 个库的全部题目作 OOD 测试，其余 10 库做温度拟合/校准。

用法:
  python make_lodo_splits.py --dev-json <bird_dev.json> --out ../lodo/lodo_splits.json
  python make_lodo_splits.py --pool <AUC>/candidates_pool.jsonl --out ../lodo/lodo_splits_bird300.json
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from collections import defaultdict

DEFAULT_POOL = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "data", "pools", "bird300_ds_pool.jsonl")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--dev-json", default=None, help="BIRD dev.json（1534 题）")
    ap.add_argument("--pool", default=None, help="候选池 jsonl（BIRD-300 池）")
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    if not args.dev_json and not args.pool:
        ap.error("需要 --dev-json 或 --pool 其一")
        return

    if args.dev_json:
        with open(args.dev_json, encoding="utf-8") as f:
            items = json.load(f)
        qid_of = lambda i, r: i  # dev.json 无稳定 id，用行号
        pairs = [(qid_of(i, r), str(r["db_id"])) for i, r in enumerate(items)]
        meta = {"source": os.path.abspath(args.dev_json), "n": len(items)}
    else:
        pairs = []
        with open(args.pool, encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    r = json.loads(line)
                    pairs.append((int(r["qid"]), str(r["db_id"])))
        meta = {"source": os.path.abspath(args.pool)}

    by_db: dict[str, set] = defaultdict(set)
    for qid, db in pairs:
        by_db[db].add(qid)

    folds = {db: {"test_qids": sorted(qids), "n_questions": len(qids)}
             for db, qids in sorted(by_db.items())}
    os.makedirs(os.path.dirname(os.path.abspath(args.out)), exist_ok=True)
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump({"meta": meta, "n_folds": len(folds), "folds": folds},
                  f, ensure_ascii=False, indent=2)
    print(f"[lodo] {len(folds)} 折 -> {args.out}")
    for db, v in folds.items():
        print(f"  {db}: {v['n_questions']} 题")


if __name__ == "__main__":
    main()
