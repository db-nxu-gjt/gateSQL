# -*- coding: utf-8 -*-
"""make_schema_drift.py — schema 漂移集（列改名 / 加列 / 拆表 三种扰动）。

对应创新点文档 §3.2 "另造 schema 漂移集：对 dev 库做列改名/加列/拆表三种
扰动，测试阈值稳定性"。

输入: AUC cache 的 DDL 文件（ddl_<db>.json, {table: "CREATE TABLE ..."}）
输出: schema_drift/<db_id>/<perturbation>/
      ├── schema.json   漂移后的 DDL（同 cache 格式，可直接喂给裁判/生成器）
      └── meta.json     扰动明细（rename_map / added / split 说明）
兼容性说明（所有扰动均保证原 gold SQL 可执行）:
  - rename   : 全库同步改写列定义与本表 FK 源列、他表 `references` 目标列
  - add_col  : 新列插入到第一个表级约束之前（DEFAULT NULL，不影响原 SQL）
  - split_tbl: 无 FK 关联的叶子表拆为 <T>__main + <T>_ext，并用同名 VIEW
               兼容原 SQL（执行不变，但裁判看到的 schema 碎片化）
  - sqlite_sequence 等内部表一律跳过

用法:
  python make_schema_drift.py --cache-dir <AUC>/data_judge/cache --out ../schema_drift
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sqlite3

DEFAULT_CACHE = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "data", "ddl")

# 列定义行：4 空格缩进 + 列名 + 类型...，行尾逗号单独捕获（re.M 下 $ 为行尾）
COL_LINE = re.compile(r"^(\s{4})(\w+)(\s+\w+.*?)(,)?\s*$", re.M)
# 表级约束（区别于列约束续行：必须跟左括号或 constraint 名）
TABLE_CONSTRAINT = re.compile(
    r"^\s*(?:foreign key\s*\(|unique\s*\(|check\s*\(|primary key\s*\("
    r"|constraint\s+\w+)", re.M | re.I)
# 表级约束子句（用于列改名时同步括号内的列名）
CONSTRAINT_CLAUSE = re.compile(
    r"((?:primary key|unique|foreign key|check)\s*\()([^)]*)(\))", re.I)


def load_tables(cache_dir: str, db_id: str) -> dict:
    with open(os.path.join(cache_dir, f"ddl_{db_id}.json"), encoding="utf-8") as f:
        tables = json.load(f)
    return {t: d for t, d in tables.items()
            if not t.lower().startswith("sqlite_")}


def table_cols(ddl: str) -> list[str]:
    cols = []
    for m in COL_LINE.finditer(ddl):
        name = m.group(2)
        if name.lower() in ("primary", "foreign", "unique", "check", "constraint"):
            continue
        cols.append(name)
    return cols


def pick_columns(cols: list[str], k: int, salt: str) -> list[str]:
    return sorted(cols, key=lambda c: hashlib.md5(f"{salt}:{c}".encode()).hexdigest())[:k]


# ---------------------------------------------------------------- rename #
def perturb_rename(tables: dict, db_id: str) -> tuple[dict, dict]:
    rename_map: dict[str, str] = {}   # "table.col" -> new_name
    per_table_picks: dict[str, set] = {}
    for t, ddl in tables.items():
        cols = table_cols(ddl)
        if not cols:
            continue
        picks = set(pick_columns(cols, min(2, max(1, len(cols) // 3)), db_id + t))
        per_table_picks[t] = picks
        for c in picks:
            rename_map[f"{t}.{c}"] = f"{c}_v2"

    def rewrite(ddl: str, own_table: str) -> str:
        picks = per_table_picks.get(own_table, set())
        # 0) 本表表级约束括号内的列名同步改名（primary key (a, b) 等）
        if picks:
            def cons_sub(m):
                inner = m.group(2)
                for c in picks:
                    inner = re.sub(rf"\b{re.escape(c)}\b", f"{c}_v2", inner)
                return m.group(1) + inner + m.group(3)
            ddl = CONSTRAINT_CLAUSE.sub(cons_sub, ddl)
        # 1) 本表列定义行改名（保留行尾逗号）
        def col_sub(m):
            head, name, rest, comma = m.groups()
            if name in picks:
                return f"{head}{name}_v2{rest}{comma or ''}"
            return m.group(0)
        ddl = COL_LINE.sub(col_sub, ddl)
        # 2) 本表 FK 源列: foreign key (<col>) -> renamed
        for c in picks:
            ddl = re.sub(rf"(foreign key\s*\(\s*){re.escape(c)}(\s*\))",
                         rf"\g<1>{c}_v2\g<2>", ddl, flags=re.I)
        # 3) 他表 references <own_table> (<col>) -> renamed
        for key, new in rename_map.items():
            t2, c2 = key.split(".", 1)
            if t2 != own_table:
                continue
            ddl = re.sub(rf"(references\s+{re.escape(t2)}\s*\(\s*)"
                         rf"{re.escape(c2)}(\s*\))",
                         rf"\g<1>{new}\g<2>", ddl, flags=re.I)
        return ddl

    new_tables = {t: rewrite(ddl, t) for t, ddl in tables.items()}
    return new_tables, {"rename_map": rename_map}


# --------------------------------------------------------------- add_col #
def perturb_add_col(tables: dict, db_id: str) -> tuple[dict, dict]:
    new_tables, added = {}, {}
    for t, ddl in tables.items():
        col = "drift_audit_col TEXT DEFAULT NULL"
        insert_at = None
        # 只认列定义边界上的表级约束：前文（去空白）必须以逗号结尾，
        # 否则是跨行列约束续行（如 `constraint x\n primary key`）
        for m in TABLE_CONSTRAINT.finditer(ddl):
            if ddl[:m.start()].rstrip().endswith(","):
                insert_at = m.start()
                break
        if insert_at is not None:
            prefix = ddl[:insert_at].rstrip()
            ddl2 = prefix + "\n    " + col + ",\n" + ddl[insert_at:]
        else:
            # 无表级约束：插到收尾 ) 之前（吞掉可能残留的尾逗号）
            close = ddl.rstrip().rfind(")")
            ddl2 = ddl[:close].rstrip().rstrip(",") + ",\n    " + col + "\n" + ddl[close:]
        new_tables[t] = ddl2
        added[t] = col
    return new_tables, {"added": added}


# ------------------------------------------------------------- split_tbl #
def perturb_split(tables: dict, db_id: str) -> tuple[dict, dict]:
    """基于 sqlite 重建：拆无 FK 叶子表为 __main + _ext，同名 VIEW 兼容。"""
    con = sqlite3.connect(":memory:")
    for t, ddl in tables.items():
        try:
            con.execute(ddl)
        except sqlite3.Error:
            con.close()
            return dict(tables), {"split": None, "note": f"baseline DDL not executable: {t}"}

    def has_fk(ddl: str) -> bool:
        return bool(re.search(r"\bforeign key\b", ddl, re.I))

    def referenced(t: str) -> bool:
        return any(re.search(rf"references\s+{re.escape(t)}\s*\(", d2, re.I)
                   for t2, d2 in tables.items() if t2 != t)

    cands = []
    for t, ddl in tables.items():
        cols = table_cols(ddl)
        if len(cols) >= 4 and not has_fk(ddl) and not referenced(t):
            cands.append((len(cols), t))
    if not cands:
        con.close()
        return dict(tables), {"split": None, "note": "no splittable leaf table"}

    cands.sort(key=lambda x: (-x[0], x[1]))
    n_cols, target = cands[0]
    info = con.execute(f"PRAGMA table_info({target})").fetchall()
    con.close()
    # info: (cid, name, type, notnull, dflt, pk)
    pk_cols = [r[1] for r in info if r[5]]
    keep_name = pk_cols[0] if pk_cols else info[0][1]
    others = [r for r in info if r[1] != keep_name]
    half = len(others) // 2
    moved = others[half:]
    kept = others[:half]

    def col_def(name: str, ty: str, notnull: bool, dflt, pk: bool) -> str:
        parts = [f"{name} {ty or 'TEXT'}"]
        if pk:
            parts.append("PRIMARY KEY")
        if notnull:
            parts.append("NOT NULL")
        if dflt is not None:
            parts.append(f"DEFAULT {dflt}")
        return " ".join(parts)

    pk_row = next(r for r in info if r[1] == keep_name)
    main_ddl = (f"CREATE TABLE {target}__main\n(\n    "
                + col_def(pk_row[1], pk_row[2], pk_row[3], pk_row[4], bool(pk_cols))
                + ",\n    " + ",\n    ".join(
                    col_def(r[1], r[2], r[3], r[4], False) for r in kept) + "\n)")
    ext_ddl = (f"CREATE TABLE {target}_ext\n(\n    "
               + col_def(keep_name, pk_row[2], False, None, False)
               + ",\n    " + ",\n    ".join(
                   col_def(r[1], r[2], r[3], r[4], False) for r in moved) + "\n)")
    moved_names = [r[1] for r in moved]
    view_ddl = (f"CREATE VIEW {target} AS SELECT m.*, "
                + ", ".join(f"e.{c}" for c in moved_names)
                + f" FROM {target}__main m JOIN {target}_ext e "
                + f"ON m.{keep_name} = e.{keep_name};")

    new_tables = {t: d for t, d in tables.items() if t != target}
    new_tables[target + "__main"] = main_ddl
    new_tables[target + "_ext"] = ext_ddl
    new_tables[target] = view_ddl  # 同名 VIEW 兼容原 SQL（dict 顺序保证最后建）
    meta = {"split": {"table": target, "moved_cols": moved_names,
                      "pk": keep_name, "compat_view": view_ddl,
                      "note": "原 SQL 经同名 VIEW 兼容；裁判看到的是碎片化 schema"}}
    return new_tables, meta


PERTURBATIONS = {"rename": perturb_rename, "add_col": perturb_add_col,
                 "split_tbl": perturb_split}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--cache-dir", default=DEFAULT_CACHE)
    ap.add_argument("--out", required=True)
    ap.add_argument("--dbs", nargs="*", default=None,
                    help="指定库（默认全部 ddl_*.json）")
    args = ap.parse_args()

    files = sorted(f for f in os.listdir(args.cache_dir)
                   if f.startswith("ddl_") and f.endswith(".json"))
    if args.dbs:
        files = [f"ddl_{d}.json" for d in args.dbs]
    n_ok = 0
    for fn in files:
        db_id = fn[4:-5]
        tables = load_tables(args.cache_dir, db_id)
        for pname, fnp in PERTURBATIONS.items():
            new_tables, meta = fnp(tables, db_id)
            # 生成后自校验：全部 DDL 必须可在 sqlite 中建表
            con = sqlite3.connect(":memory:")
            try:
                for t, ddl in new_tables.items():
                    con.execute(ddl)
                valid = True
            except sqlite3.Error as e:
                valid = False
                print(f"[warn] {db_id}/{pname} DDL 校验失败: {e}")
            finally:
                con.close()
            out_dir = os.path.join(args.out, db_id, pname)
            os.makedirs(out_dir, exist_ok=True)
            with open(os.path.join(out_dir, "schema.json"), "w",
                      encoding="utf-8") as f:
                json.dump(new_tables, f, ensure_ascii=False, indent=1)
            with open(os.path.join(out_dir, "meta.json"), "w",
                      encoding="utf-8") as f:
                json.dump({"db_id": db_id, "perturbation": pname,
                           "valid": valid, "meta": meta},
                          f, ensure_ascii=False, indent=2)
            n_ok += int(valid)
        print(f"[drift] {db_id}: 3 种扰动已生成")
    print(f"[done] {n_ok}/{len(files) * 3} 个扰动集通过 sqlite 建表校验 -> {args.out}")


if __name__ == "__main__":
    main()
