# -*- coding: utf-8 -*-
"""盘点 schema_drift 变体有效性（临时盘点脚本）。"""
import json
import os

base = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "schema_drift")
for db in sorted(os.listdir(base)):
    row = []
    for p in ("rename", "add_col", "split_tbl"):
        fp = os.path.join(base, db, p, "meta.json")
        m = json.load(open(fp, encoding="utf-8"))
        v = m.get("valid")
        detail = ""
        if p == "rename":
            detail = str(len(m["meta"].get("rename_map", {}))) + " cols"
        elif p == "add_col":
            detail = str(len(m["meta"].get("added", {}))) + " tables"
        else:
            sp = m["meta"].get("split")
            detail = sp["table"] if sp else "none"
        row.append("%s:%s(%s)" % (p, "Y" if v else "N", detail))
    print("%-26s %s" % (db, " | ".join(row)))
