# -*- coding: utf-8 -*-
"""validate_drift.py — 端到端验证 split_tbl 兼容视图：原 SQL 经视图跑出与原库一致的结果。

用后即删的临时验证脚本（也可保留作回归检查）。
"""
import json
import sqlite3
import os

HERE = os.path.dirname(os.path.abspath(__file__))
DB, PERT = "debit_card_specializing", "split_tbl"
orig_db = os.environ.get("GATE_BIRD_DBS") or os.path.join(
    HERE, "..", "bird", "databases", DB, DB + ".sqlite")

meta = json.load(open(os.path.join(HERE, "..", "schema_drift", DB, PERT, "meta.json"),
                      encoding="utf-8"))["meta"]["split"]
tables = json.load(open(os.path.join(HERE, "..", "schema_drift", DB, PERT, "schema.json"),
                        encoding="utf-8"))
target, ext_t, pk, moved = meta["table"], meta["table"] + "_ext", meta["pk"], meta["moved_cols"]
main_t = target + "__main"
print("split:", target, "->", main_t, "+", ext_t, "| moved:", moved)

orig = sqlite3.connect(orig_db)
con = sqlite3.connect(":memory:")
orig.backup(con)
con.commit()

cols_main = [r[1] for r in con.execute(f"PRAGMA table_info({target})")
             if r[1] not in moved]
cols_ext = [pk] + moved
con.execute(f"DROP TABLE {target}")
for t, ddl in tables.items():
    try:
        con.execute(ddl)
    except sqlite3.OperationalError as e:
        if "already exists" in str(e):
            continue  # 未被拆分的表已在库中
        raise

qmarks = lambda n: ",".join("?" * n)
rows_main = orig.execute(f"SELECT {','.join(cols_main)} FROM {target}").fetchall()
rows_ext = orig.execute(f"SELECT {','.join(cols_ext)} FROM {target}").fetchall()
con.executemany(f"INSERT INTO {main_t} ({','.join(cols_main)}) VALUES ({qmarks(len(cols_main))})",
                rows_main)
con.executemany(f"INSERT INTO {ext_t} ({','.join(cols_ext)}) VALUES ({qmarks(len(cols_ext))})",
                rows_ext)
con.commit()

q = ("SELECT t.Date, t.Amount, c.Segment FROM transactions_1k t "
     "JOIN customers c ON t.CustomerID = c.CustomerID "
     "ORDER BY t.TransactionID LIMIT 5")
r_orig = orig.execute(q).fetchall()
r_drift = con.execute(q).fetchall()
print("view rows match original:", r_orig == r_drift)
print("sample:", r_drift[0] if r_drift else None)
