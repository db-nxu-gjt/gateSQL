# -*- coding: utf-8 -*-
"""make_pool.py — 候选池生成（BIRD dev 1534 / Spider dev / 温度拟合集）。

对应创新点文档 §3.2 生成协议（对齐 EMNLP 2025 校准论文）:
  每题生成 10 个 nucleus（T=0.8, top_p=0.95）+ 10 个 beam 近似
  （API 下用 T=0.2 低温柔示，若端点为 vLLM 可用 --beam-real 真波束），
  取候选池供所有置信方法评分（所有方法评同一批 SQL）。
  --logprobs 模式为 B3/B4 白盒基线生成 token 级 logprobs（需开源模型端点）。

生成后自动执行标注（RGCV 严格匹配协议），输出:
  pools/<name>_pool.jsonl     候选池
  pools/<name>_labels.jsonl   执行标注（correct/silent/exec_fail）

用法:
  # BIRD dev 全量（需官方 dev.json；每题 20 候选 × 1534 题，注意配额）
  python make_pool.py --dataset bird --dev-json <bird_dev.json> --out ../pools/bird1534
  # Spider dev
  python make_pool.py --dataset spider --dev-json <spider_dev.json> --out ../pools/spider_dev
  # 开源模型 + logprobs（B3/B4 用）
  python make_pool.py --dataset bird --dev-json <bird_dev.json> \
      --out ../pools/bird1534_qwen32b --logprobs --model Qwen/Qwen3-32B
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                "..", "..", "baseline"))
from common.schema import Candidate, write_jsonl  # noqa: E402
from common import exec_match  # noqa: E402
from common.llm_client import LLMClient  # noqa: E402

GEN_PROMPT = """You are a Text-to-SQL expert. Given the database schema, question and hint, write ONE SQLite query.

### Schema
{schema}

### Question
{question}
{evidence}
Respond with ONLY the SQL query (single line, no markdown, no explanation)."""

# 输出截断：单行 SQL 协议下合法输出不含空行，遇空行即停，
# 防止模型在 SQL 后继续解释性长文（输出 token 是计费大头）。
GEN_STOP = ["\n\n"]


def load_ddl(cache_dir: str | None, db_id: str, spider_dir: str | None) -> str:
    if cache_dir:
        p = os.path.join(cache_dir, f"ddl_{db_id}.json")
        if os.path.exists(p):
            with open(p, encoding="utf-8") as f:
                return "\n\n".join(json.load(f).values())
    if spider_dir:  # Spider: tables.json -> 拼接该库建表语句（简化：直接给 schema dump）
        p = os.path.join(spider_dir, "database", db_id, "schema.sql")
        if os.path.exists(p):
            with open(p, encoding="utf-8", errors="ignore") as f:
                return f.read()
    return ""


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", required=True, choices=["bird", "spider"])
    ap.add_argument("--dev-json", required=True)
    ap.add_argument("--out", required=True, help="输出前缀，如 ../pools/bird1534")
    ap.add_argument("--model", default=None)
    ap.add_argument("--ddl-cache", default=None,
                    help="BIRD DDL 缓存目录（默认 AUC cache）")
    ap.add_argument("--spider-dir", default=None,
                    help="Spider 数据目录（含 database/<db>/schema.sql）")
    ap.add_argument("--n-nucleus", type=int, default=10)
    ap.add_argument("--n-beam", type=int, default=10)
    ap.add_argument("--max-tokens", type=int, default=384,
                    help="单次生成上限（默认 384：BIRD 最长 gold SQL ~250 token，"
                         "收紧以省输出费用且不影响合法候选）")
    ap.add_argument("--logprobs", action="store_true",
                    help="请求 token logprobs（B3/B4 用；DeepSeek 已实测支持）")
    ap.add_argument("--qids-json", default=None,
                    help="只生成指定 qid 的题（json 数组），与既有池同题对齐")
    ap.add_argument("--workers", type=int, default=8,
                    help="题间并行数（DeepSeek n=1 限制下按次调用，需并行提速）")
    ap.add_argument("--nucleus-temp", type=float, default=0.8)
    ap.add_argument("--beam-temp", type=float, default=0.2)
    ap.add_argument("--extra-json", default=None,
                    help="附加 payload（json 字符串，如 {\"reasoning_effort\":\"none\"}）")
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--resume", action="store_true", default=True)
    args = ap.parse_args()

    if args.ddl_cache is None and args.dataset == "bird":
        args.ddl_cache = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "data", "ddl")

    with open(args.dev_json, encoding="utf-8") as f:
        dev = json.load(f)
    if args.limit:
        dev = dev[: args.limit]

    pool_path = args.out + "_pool.jsonl"
    labels_path = args.out + "_labels.jsonl"
    done: set[tuple] = set()
    if args.resume and os.path.exists(pool_path):
        with open(pool_path, encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    r = json.loads(line)
                    done.add((r["qid"], r["source"], r["cand_idx"]))
        print(f"[resume] 池中已有 {len(done)} 条")

    keep = None
    if args.qids_json:
        with open(args.qids_json, encoding="utf-8") as f:
            keep = set(json.load(f))
        print(f"[qids] 只生成 {len(keep)} 个指定 qid")

    done_qids = {k[0] for k in done}
    tasks = []
    for qi, item in enumerate(dev):
        if keep is not None and qi not in keep:
            continue
        if args.resume and qi in done_qids:
            continue
        tasks.append((qi, item))
    print(f"[pool] 待生成 {len(tasks)} 题 (workers={args.workers})")

    cli = LLMClient(model=args.model)
    extra = json.loads(args.extra_json) if args.extra_json else None
    os.makedirs(os.path.dirname(os.path.abspath(pool_path)), exist_ok=True)
    out_f = open(pool_path, "a", encoding="utf-8")
    n_new = 0

    def gen_question(qi: int, item: dict) -> list[dict]:
        """单题全部候选（线程内只生成不写盘，主线程统一写入）。"""
        qid, db_id = qi, item["db_id"]
        schema = load_ddl(args.ddl_cache, db_id, args.spider_dir)
        ev = f"Hint: {item.get('evidence', '')}\n" if item.get("evidence") else ""
        prompt = GEN_PROMPT.format(schema=schema, question=item["question"],
                                   evidence=ev)

        def emit(texts: list, source: str, tokens_list=None) -> list[dict]:
            rows = []
            for ci, sql in enumerate(texts):
                sql = sql.strip().strip("`").removeprefix("sql\n").strip()
                if not sql:
                    continue
                rec = Candidate(
                    qid=qid, source=source, cand_idx=ci, db_id=db_id,
                    sql=sql, gold_sql=item.get("query") or item.get("SQL", ""),
                    question=item["question"],
                    evidence=item.get("evidence", ""),
                    difficulty=item.get("difficulty", ""),
                )
                if tokens_list is not None:
                    rec.tokens = tokens_list[ci]["tokens"]
                    rec.token_logprobs = tokens_list[ci]["token_logprobs"]
                rows.append(rec.to_row())
            return rows

        rows = []
        if args.n_nucleus > 0:
            if args.logprobs:
                nuc = cli.generate_with_logprobs(
                    prompt, n=args.n_nucleus, temperature=args.nucleus_temp,
                    top_p=0.95, max_tokens=args.max_tokens, extra=extra)
                rows += emit([b["text"] for b in nuc],
                             f"nucleus{args.n_nucleus}", nuc)
            else:
                nuc = cli.generate(prompt, n=args.n_nucleus,
                                   temperature=args.nucleus_temp, top_p=0.95,
                                   max_tokens=args.max_tokens, stop=GEN_STOP,
                                   extra=extra)
                rows += emit(nuc, f"nucleus{args.n_nucleus}")
        if args.n_beam > 0:
            if args.logprobs:
                bms = cli.generate_with_logprobs(
                    prompt, n=args.n_beam, temperature=args.beam_temp,
                    max_tokens=args.max_tokens, extra=extra)
                rows += emit([b["text"] for b in bms],
                             f"beam{args.n_beam}", bms)
            else:
                bms = cli.generate(prompt, n=args.n_beam,
                                   temperature=args.beam_temp,
                                   max_tokens=args.max_tokens, stop=GEN_STOP,
                                   extra=extra)
                rows += emit(bms, f"beam{args.n_beam}")
        return rows

    try:
        with ThreadPoolExecutor(max_workers=max(1, args.workers)) as ex:
            futs = {ex.submit(gen_question, qi, item): qi for qi, item in tasks}
            for fi, fut in enumerate(as_completed(futs), 1):
                qi = futs[fut]
                try:
                    rows = fut.result()
                except Exception as e:  # 单题失败不中断，重跑（resume）可补
                    print(f"[warn] qid={qi} 生成失败: {e}", flush=True)
                    continue
                if rows:
                    out_f.write("".join(json.dumps(r, ensure_ascii=False) + "\n"
                                        for r in rows))
                    out_f.flush()
                    n_new += len(rows)
                if fi % 10 == 0 or fi == len(futs):
                    print(f"[pool] {fi}/{len(futs)} 题完成, 新增 {n_new} 条",
                          flush=True)
    finally:
        out_f.close()

    # 执行标注（断点续跑缓存）
    from common.schema import load_pool
    cands = load_pool(pool_path)
    labels = exec_match.label_pool(cands, args.dataset, cache_path=labels_path)
    with open(labels_path, "w", encoding="utf-8") as f:
        for (q, s, ci), lab in sorted(labels.items()):
            f.write(json.dumps({"qid": q, "source": s, "cand_idx": ci,
                                "label": lab}) + "\n")

    n_corr = sum(1 for v in labels.values() if v == "correct")
    print(f"[done] pool={pool_path} labels={labels_path} "
          f"({len(labels)} 条, EX={n_corr / max(1, len(labels)):.3f})")


if __name__ == "__main__":
    main()
