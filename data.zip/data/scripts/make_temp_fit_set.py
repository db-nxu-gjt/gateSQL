# -*- coding: utf-8 -*-
"""make_temp_fit_set.py — Spider train 抽 500 题作温度拟合集（防泄漏）。

对应创新点文档 §3.2: "温度拟合集：从 Spider train 抽 500 题（与 dev 零重叠
的库），生成候选后拟合各题温度与阈值——dev 集绝不做任何调参"。

要求 Spider 官方数据包（含 train_spider.json / dev.json / databases/）。
官方下载: https://yale-lily.github.io/spider （需手动下载一次 zip）。

输出: temp_fit500/questions.jsonl
  {"qid": i, "db_id": ..., "question": ..., "query": ..., "db_path": ...}
  qid 为全局递增 id；保证与 dev 库零重叠。

用法:
  python make_temp_fit_set.py --spider-dir <解压后的 Spider 目录> \
      --out ../temp_fit500/questions.jsonl [--n 500] [--seed 0]
"""
from __future__ import annotations

import argparse
import json
import os
import random
from collections import defaultdict


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--spider-dir", required=True,
                    help="含 train_spider.json 与 dev.json 的 Spider 目录")
    ap.add_argument("--databases-dir", default=None,
                    help="sqlite 库目录（默认 <spider-dir>/databases；复用其他目录的库时指定）")
    ap.add_argument("--out", required=True)
    ap.add_argument("--n", type=int, default=500)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()

    with open(os.path.join(args.spider_dir, "train_spider.json"),
              encoding="utf-8") as f:
        train = json.load(f)
    with open(os.path.join(args.spider_dir, "dev.json"), encoding="utf-8") as f:
        dev = json.load(f)

    dev_dbs = {r["db_id"] for r in dev}
    train_dbs = {r["db_id"] for r in train}
    overlap = dev_dbs & train_dbs
    if overlap:  # 官方划分本应零重叠，这里强制保证
        print(f"[warn] train 与 dev 库重叠 {len(overlap)}: {sorted(overlap)}（已剔除）")
        train = [r for r in train if r["db_id"] not in overlap]

    by_db: dict[str, list] = defaultdict(list)
    for r in train:
        by_db[r["db_id"]].append(r)
    dbs = sorted(by_db)
    rng = random.Random(args.seed)

    picked: list[dict] = []
    # 每库轮转抽取，保证库多样性，直至凑满 n
    i = 0
    while len(picked) < args.n:
        progressed = False
        for db in dbs:
            if i < len(by_db[db]):
                picked.append(by_db[db][i])
                progressed = True
                if len(picked) >= args.n:
                    break
        if not progressed:
            break
        i += 1
    rng.shuffle(picked)
    picked = picked[: args.n]

    db_dir = args.databases_dir or os.path.join(args.spider_dir, "databases")
    missing = [db for db in {r["db_id"] for r in picked}
               if not os.path.isfile(os.path.join(db_dir, db, db + ".sqlite"))]
    if missing:
        raise SystemExit(f"[temp_fit] 缺少 sqlite 库 {len(missing)} 个: {sorted(missing)}")

    rows = []
    for i, r in enumerate(picked):
        rows.append({
            "qid": i,
            "db_id": r["db_id"],
            "question": r["question"],
            "query": r["query"],
            "db_path": os.path.join(db_dir, r["db_id"], r["db_id"] + ".sqlite"),
        })
    os.makedirs(os.path.dirname(os.path.abspath(args.out)), exist_ok=True)
    with open(args.out, "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"[temp_fit] {len(rows)} 题 / {len({r['db_id'] for r in rows})} 库 -> {args.out}")


if __name__ == "__main__":
    main()
