# BIRD dev databases (download separately)

The candidate pools in `data/pools/` were built on the BIRD development split
([BIRD, Li et al., NeurIPS 2023](https://arxiv.org/abs/2305.03111),
<https://bird-bench.github.io/>). The SQLite databases are ~several GB and are
**not** included in this repository.

1. Download the BIRD dev dataset (`dev.zip`) from <https://bird-bench.github.io/>
   (Google-Drive / OpenXLab links on the page; dataset version 1.0.1).
2. Unzip so that each database lives at
   `data/bird/databases/<db_id>/<db_id>.sqlite`.
3. Optionally place `dev.json` (the 1,534 dev questions) at `data/bird/dev.json`
   (used by `data/scripts/make_lodo_splits.py` and the difficulty stratification).

`baseline/common/exec_match.py` resolves databases via the `GATE_BIRD_DBS`
environment variable, defaulting to `data/bird/databases`; point it anywhere
if you keep the databases elsewhere.

BIRD is released under CC BY-SA 4.0. The candidate pools under `data/pools/`
embed BIRD dev questions/evidence and gold SQL; if you redistribute them,
keep this attribution. The 11 DDL files in `data/ddl/` are extracted from the
same BIRD dev databases.
